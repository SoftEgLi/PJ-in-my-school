//类的前向声明

class Element;
class File;
class Folder;
class HuffmanTree;
class Node;
class Observer;
class Decompress;
class Compress;
class Preview;