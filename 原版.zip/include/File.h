//文件类和文件夹类

#include"head.h"

class Element{
    protected: 
            string type;
            ll length;
            string path;
            string name;
    public:Element(string type,string path,string name){
                this->type = type;
                this->path = path;
                this->name = name;
            }
            friend class Decompress;
            friend class Compress;
            friend class Preview;
};

class File:public Element{
    private:
        ll com_length;
    public:
        File(string path,string name):Element("File",path,name){};
        friend class Decompress;
        friend class Compress;
};
class Folder:public Element{
    public:
        Folder(string path,string name):Element("Folder",path,name){};
        friend class Compress;
        friend class Decompress;
};