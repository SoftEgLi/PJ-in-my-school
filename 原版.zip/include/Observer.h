//Compress类，Decompress类，Preview类分别对应 压缩功能，解压功能，预览功能
#include"head.h"
class Observer{
    public:virtual void visit(Element* const element)=0;
};
class Decompress:public Observer{
    private:
        ifstream infile;
        ofstream outfile;
        map<string,char> decom_map;
        map<char,ll> char_count;
        HuffmanTree* hf;
        void decompress();
        void decom_file(File* file);

    public:
        Decompress(){};
        void visit(Element* const element);
        // void visit2(string name);
        
};
class Compress:public Observer{
    private:
        ifstream infile;
        ofstream outfile;
        map<char,string> com_map;
        string out_name;
        map<char,ll> char_count;
        void Build_Huffman_Code(Element* const element);
        void visitFile(Element* const element);
        void visitFolder(Element* const element);
        void output_compress_context(Element* element,ll& com_length);
        void Stack_Visit(string root);
    public:
        Compress(string out_name){
            this->out_name = out_name;
        }
        void visit(Element* const element);
        
};
class Preview:public Observer{
    private:
        ifstream infile;
        void show();
    public:
        void visit(Element* const element);
};
// void folder_recur(ifstream& infile,string prefix){
