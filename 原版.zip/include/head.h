//放置库函数

#include<iostream>
#include<vector>
#include<map>
#include<fstream>
#include"classlist.h"
#include<io.h>
#include<string>
#define ll long long int
using namespace std;