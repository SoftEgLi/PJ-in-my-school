//Node类和HuffmanTree类

#include"head.h"
#define ll long long int
class Node{
    private:       
        int value;
        ll weight;
        Node* left;
        Node* right;
    public:
        Node(){}
        Node(int value,ll weight,Node* left,Node* right){
            this->value = value;
            this->weight = weight;
            this->left = left;
            this->right = right;
        }
        ll getweight(){
            return weight;
        }
        friend class HuffmanTree;
        friend class Decompress;
};

class HuffmanTree{
    private:
        Node* root;
        void recursion(map<char,string>& binary_map,Node* node,string prefix);
    public:
        HuffmanTree(map<char,ll> map_count);
        map<char,string> Create_Code();
        friend class Decompress;
};
