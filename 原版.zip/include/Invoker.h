//交互类，用来处理与用户的交互指令

#include"head.h"
struct Parameter{
    string mode;
    string first_name;
    string second_name;
};
class Invoker{
    private:
        Parameter para;
        void compress(Parameter para);
        void decompress(Parameter para);
        void preview(Parameter para);  
        bool check_overwrite(Parameter para);
        bool check_format(Parameter para);
    public:
        void invoke(int argc,char* argv[]);
};

