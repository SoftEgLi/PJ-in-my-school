string sub_str(string line,int idx);    //求子串
ll get_file_length(ifstream& infile);   //获得文件字节长度
string Delete_comma(string line);       //删除逗号,用于压缩功能的实现。压缩时输出了逗号，需要删去
string Parent_dir(string dir);          //返回上一级目录
int Cal_space(string line);             //计算空格数。因为要通过空格的数量来表示文件夹的层次
bool isFile(string s);                  //判断是否是文件
