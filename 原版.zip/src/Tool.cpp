//一些辅助函数

#include"head.h"
#include"Tool.h"

string sub_str(string line,int idx){        //获得字串
    string ans = "";
    int length = line.length();     //去掉换行符
    for(int i=idx;i<length;i++){
        if(line[i]=='\n'){
            break;
        }
        ans+=line[i];
    }
    return ans;

}

bool isFile(string s){
	int length = s.size();
	for(int i=0;i<s.size();i++){
		if(s[i]=='.')return true;
	}
	return false;
}

ll get_file_length(ifstream& infile){    //取得文件的字节长度
    infile.seekg(0,infile.end);            
    auto a = infile.tellg();
    return a;
}

string Delete_comma(string line){    //删除逗号,用于压缩功能的实现。压缩时输出了逗号，需要删去
    string ans="";
    int length = line.size();
    for(int i=0;i<length;i++){
        if(line[i]==',')break;
        ans+=line[i];
    }
    return ans;
}
string Parent_dir(string dir){              //返回上一级目录
    int length = dir.size();
    int count = 0;
    int i;
    for(i=length-1;i>=0;i--){
        if(dir[i]=='/'){
            count++;
            if(count==2)
                break;
        }
    }
    string ans="";
    if(i==-1)return ans;
    ans = dir.substr(0,i+1);
    return ans;
}
int Cal_space(string line){             //计算空格数。因为要通过空格的数量来表示子文件夹
    int length = line.length()-1;
    int ans=0;
    for(int i=0;;i++){
        if(line[i]!=' ')break;
        ans++;
    }
    return ans;
}