//实现压缩功能

#include"Observer.h"
#include"File.h"
#include"HuffmanTree.h"
#include"Tool.h"
#include<queue>
#include<stack>
#include<filesystem>
namespace fs = filesystem;

void Compress::Build_Huffman_Code(Element* const element){
    this->infile.open(element->path,ios::binary);
    char in[1600000];                    //一次读取约1.6MB
    map<char,ll> map_count;
    int in_count=0;             //记录读取的次数，每次读取1.6MB
    this->infile.read(in,1600000);       //先读一次，防止出现read最后一个字符两次的情况
    in_count++;                          
    while(!infile.eof()){
        for(int i=0;i<1600000;i++){      //用map_count记录每种字符出现的次数,map_count的数据类型是map
            map_count[in[i]]+=1;
        }
        in_count++;
        infile.read(in,1600000);     //不保存txt，防止内存不够
    }
    int end = element->length - (in_count-1)*1600000;
    for(int i=0;i<end;i++){  //对最后一次读取的字符进行处理
        map_count[in[i]]+=1;
    }                                   //文件中的字符处理完成
    infile.close();
    infile.open(element->path,ios::binary);         
    if(!infile)cout<<"infile error";
    this->char_count = map_count;
    HuffmanTree hf(map_count);
    this->com_map = hf.Create_Code();                   //建立霍夫曼树，并产生霍夫曼编码
}



class OString{
    public:
        string prefix;
        fs::path path_1;
        OString(string prefix,fs::path path_1):prefix(prefix),path_1(path_1){};
};
//文件夹会输出文件夹的名字，
//文件则输出文件名字，压缩前的字符长度，压缩后的字符长度，文件的霍夫曼编码，以及文件编码后的内容
void Compress::Stack_Visit(string root){                //Stack
    fs::path rp(root);
    stack<OString> s;
    s.emplace("",rp);
    while(1){
        if(s.empty())break;
        OString os = s.top();
        s.pop();
        if(!fs::is_directory(os.path_1)){
            File f1(os.path_1.string(),os.path_1.filename().string());
            outfile<<os.prefix;
            this->visitFile(&f1);
            outfile<<'\n';
        }
        else{
            outfile<<os.prefix<<os.path_1.filename().string();
            outfile<<"\n";
            for(const auto& iter :fs::directory_iterator(os.path_1)){
                fs::path p(iter.path().string());
                s.emplace(os.prefix+" ",p);
            }
        }
    }
}   
void Compress::visitFolder(Element* const element){
    this->Stack_Visit(element->path);
}


void Compress::output_compress_context(Element* element,ll& com_length){
    char in[1600000];                   //一次读取约1.6MB
    int in_count=0;                     //记录读取次数，每次读取约1.6MB
    char save;                          //编码后以单个字节的方式输出
    string out="";
    int buff[8];                        //缓冲区
    int buff_count=0;                   //记录缓冲区的有效个数，每到8就输出一个字节
    infile.read(in,1600000);         //先读取一次，防止出现末尾读取两次的情况
    in_count++;
    while(!infile.eof()){

        for(int j =0;j<1600000;j++){         //循环1.6MB次
            out=com_map[in[j]];                 //out为编码后的只有'0','1'的字符串
            int out_length = out.length();
            for(int i=0;i<out_length;i++){
                buff[buff_count] = out[i]-'0';  //buff_count记录缓冲区的有效个数
                buff_count++;
                if(buff_count==8){          //当缓冲区满时，buff_count = 0 ,并输出字符
                    com_length++;
                    buff_count=0;       //下面一行将‘0’，‘1’等字符转化为8位2进制数，以char的形式输出
                    save = buff[0]*128+buff[1]*64+buff[2]*32+buff[3]*16+buff[4]*8+buff[5]*4+buff[6]*2+buff[7]*1;
                    outfile.write(&save,sizeof(char));
                }
            }
        }
        in_count++;
        infile.read(in,1600000);
    }
    ll temp = element->length-(in_count-1)*sizeof(in);
    for(int j=0;j<temp;j++){     //上面的循环无法处理最后一次读取的内容
        out=com_map[in[j]];                                         //这里单独处理一下
        int out_length = out.length();
        for(int i=0;i<out_length;i++){
            buff[buff_count] = out[i]-'0';
            buff_count++;
            if(buff_count==8){
                com_length++;
                buff_count=0;
                save = buff[0]*128+buff[1]*64+buff[2]*32+buff[3]*16+buff[4]*8+buff[5]*4+buff[6]*2+buff[7]*1;
                outfile<<save;
            }
        }
    }
    save = 0;               //缓冲区可能有残留，要单独处理
    int mul = 128;
    if(buff_count>0){           
        com_length++;
        for(int i=0;i<buff_count;i++){
            save+= buff[i]*mul;
            mul/=2;
        }
        outfile<<save;
    }

}
//压缩单个文件的函数
//输出文件名字，压缩前的字符长度，压缩后的字符长度，文件的霍夫曼编码，以及文件编码后的内容
void Compress::visitFile(Element* const element){
    map<char,string> temp;  
    this->com_map = temp;           //初始化
    ifstream infile(element->path,ios::binary);
    if(!infile){
        cout<<"File doesn't exist"<<endl;
        return;
    }


    element->length = get_file_length(infile);
    infile.close();
    infile.open(element->path,ios::binary);
    cout<<"Begin compressing"<<" "<<element->name<<endl;
    outfile<<element->name<<" "<<element->length<<":" ;        //输出文件名字，压缩前的字符长度
    if(element->length==0){                         //处理空文件情况，压缩后的字符长度是0
        outfile<<'0';
        return;
    }

    this->Build_Huffman_Code(element);                  //建立霍夫曼编码
    ll pos = outfile.tellp();
    ll temp_length = element->length;
    ll com_length=0;        //记录压缩后的字节数量
    for(int i=0;;i++){                      //输出','来保留位置，该位置用来存储压缩后的字节数 
        temp_length/=10;                //默认保留与压缩前字节相同的位数，如压缩前字节为4位数，就输出4个','
        outfile<<",";
        if(temp_length==0)break;
    }
    outfile<<"\n";                      //输出换行符，之后输出霍夫曼编码
    auto char_end = this->char_count.end();
    for(auto iter= this->char_count.begin();iter!=char_end;iter++){ //输出霍夫曼编码
        if(iter->first=='\n'){
            outfile<<iter->second<<":"<<"\\n";
            continue;
        }
        outfile<<iter->second<<":"<<iter->first;
    }
    outfile<<"\n";          //输出换行符，之后开始输出编码后的内容

    this->output_compress_context(element,com_length); //输出编码后的内容
    
    ll pos_now = outfile.tellp();
    outfile.seekp(pos,ios::beg);//倒退到输出文件压缩前长度处
    outfile<<com_length;
    outfile.seekp(pos_now,ios::beg);         //返回来，因为该函数还要用在压缩文件夹的功能下
    this->infile.close();
}
void Compress::visit(Element* const element){
    this->outfile.open(this->out_name,ios::binary);
    if(element->type=="File")this->visitFile(element);
    else if(element->type=="Folder")this->visitFolder(element);
    this->outfile.close();
}

