//实现预览功能

#include"Observer.h"
#include"Tool.h"
#include"File.h"
#include"HuffmanTree.h"

void Preview::visit(Element* const element){
    this->infile.open(element->name,ios::binary);
    if(!infile){
        cout<<"File doesn't exist"<<endl;
        return;
    }
    this->show();
    this->infile.close();
}
void Preview::show(){
    string line;
    line = sub_str(line,0);
    int level = 0;
    while(!infile.eof()){
        getline(infile,line);
        line = sub_str(line,0);
        int idx = Cal_space(line);
        if(level>idx){
            int temp = level;
            for(int i=0;i<temp-idx;i++){
                level--;
            }
        }
        if(isFile(line)){                   //文件
            int idx1 = idx;
            int idx2 = line.rfind(' ');
            int idx3 = line.rfind(':');
            string name = line.substr(idx1,idx2-idx1); 
            string s_origin_len = sub_str(line,idx2+1);
            string tem_com_len = sub_str(line,idx3+1);
            string s_com_len = Delete_comma(tem_com_len);
            ll length = atoi(s_origin_len.c_str());
            ll com_len = atoi(s_com_len.c_str());
            for(int i=0;i<level;i++){
                cout<<"  ";
            }
            cout<<name<<endl;
            if(com_len==0)continue;
            string temp;
            getline(infile,temp);           //跳过存储霍夫曼树的那一行
            infile.seekg(com_len+1,ios::cur);
            
        }
        else{                               //文件夹
            string name = sub_str(line,idx);
            level++;
            for(int i=0;i<level-1;i++){
                cout<<"  ";
            }
            cout<<name<<endl;
    }   
}
}
