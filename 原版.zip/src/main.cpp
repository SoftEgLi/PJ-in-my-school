#include"File.h"
#include"Observer.h"
#include"Invoker.h"

int main(int argc, char *argv[])
{	
	Invoker iv;
	iv.invoke(argc,argv);
}