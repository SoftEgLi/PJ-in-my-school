//实现交互功能

#include"Invoker.h"       
#include"File.h"
#include"Observer.h"
#include"Tool.h"
bool Invoker::check_overwrite(Parameter para){
    if(para.mode != "-c")return false;
    ifstream infile;
    infile.open(para.first_name,ios::binary);
    if(infile){
        infile.close();
        return true;
    }
    return false;
}
bool Invoker::check_format(Parameter para){
    if(para.mode=="-c"){       //compress
        int idx = para.first_name.find('.');
        if(idx == -1)return false;
        int size = para.first_name.size();
        string format = "";
        for(int i = idx+1 ; i < size ; i++){
            format += para.first_name[i];
        }
        if(format == "save")return true;
        return false;
    }
    else if(para.mode == "-d" || para.mode == "-p"){     //decompress
        int idx = para.first_name.find('.');
        if(idx == -1)return false;
        int size = para.first_name.size();
        string format = "";
        for(int i = idx+1 ; i < size ; i++){
            format += para.first_name[i];
        }
        if(format == "save")return true;
        return false;
    }
    else{
        cout<<"Error.";
        cout<<"Please use the specified format"<<endl;
        cout<<"-c: compress your file or folder.You need to run like this:"<<endl;
        cout<<"hfzip -c test.jpg name.save"<<endl;
        cout<<"-d: decompress the compressed file.You need to run like this:"<<endl;
        cout<<"hfzip -d name.save"<<endl;
        cout<<"-p: preview the compressed file.You need to run like this:"<<endl;
        cout<<"hfzip -p name.save"<<endl;
    }
}
void Invoker::compress(Parameter para){
    string name;
    int dir_idx = para.second_name.find('/');
    if(dir_idx ==-1)name = para.second_name;
    else name = sub_str(para.second_name,dir_idx+1);
    int idx = para.second_name.find('.');
    if(idx == -1){              //文件夹
        Folder* folder = new Folder(para.second_name,name);   
        Compress com(para.first_name);
        com.visit(folder);
    }
    else{                       //文件
        File* folder = new File(para.second_name,name);   
        Compress com(para.first_name);
        com.visit(folder);
    }
}
void Invoker::decompress(Parameter para){
    File* file = new File(para.first_name,para.first_name);
    // cout<<file->length;
    Decompress de;
    de.visit(file);
}
void Invoker::preview(Parameter para){
    File* file = new File(para.first_name,para.first_name);
    Preview pv;
    pv.visit(file);
}

void Invoker::invoke(int argc, char *argv[]){
    if(argc<3){
        cout<<"Error.";
        cout<<"Please use the specified format"<<endl;
        cout<<"-c: compress your file or folder.You need to run like this:"<<endl;
        cout<<"hfzip -c test.save test.jpg"<<endl;
        cout<<"-d: decompress the compressed file.You need to run like this:"<<endl;
        cout<<"hfzip -d name.save"<<endl;
        cout<<"-p: preview the compressed file.You need to run like this:"<<endl;
        cout<<"hfzip -p name.save"<<endl;
    return;
    }
	para.mode = argv[1];
	para.first_name = argv[2];
	if(argc == 4){
	para.second_name = argv[3];
	}
    if(this->check_format(para) == false){  //格式错误
        cout<<"Format Error,not created by this compress tool.You need to run .save file"<<endl;
        return;
    }
    if(this->check_overwrite(para) == 1){   //需要重写
        cout<<para.first_name<<" exists.Do you want to overwrite?(Y/N) ";
        string s;
        while(1){
            cin >> s;
            if(s == "N")return;
            else if(s == "Y")break;
            else if(s !="Y")cout<<"Wrong input , try again"<<endl;
        }

    }
    if(para.mode == "-c"){               //compress
        this->compress(para);
        cout<<"Compressing "<<para.second_name<<" has done"<<endl;
        return;
    }
    else if(para.mode == "-d"){          //decompress
        this->decompress(para);
        cout<<"Decompressing "<<para.first_name<<" has done "<<endl;
        return;
    }
    else if(para.mode == "-p"){          //preview
        this->preview(para);
        cout<<"Previewing "<<para.first_name<<" has done "<<endl;
        return;
    }
}