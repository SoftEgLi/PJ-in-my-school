//实现解压功能

#include"Observer.h"
#include"File.h"
#include"HuffmanTree.h"
#include"Tool.h"
#include<string>
#include<filesystem>
#include<stack>
namespace fs = filesystem;

//解压单个文件
void Decompress::decom_file(File* file){

    void char_to_string(char in,char buff[8]);
    this->outfile.open(file->path,ios::binary);
    if(file->length==0){
        this->outfile.close();
        return;
    }
    string s;
    map<char,ll> init;
    this->char_count = init;
    ll second = 0;
    char first; 
    getline(infile,s);
    int length = s.size()-1;
    for(int i=0;i<length;i++){          //读取存放在压缩文件中各个char的出现次数，重新建立霍夫曼树。
        if(s[i]==':'){                 
            if(s[i+1]=='\\'&&s[i+2]=='n'){
                i+=2;               
                first = '\n';//由于'\n'会导致换行，使得通过getline得到的霍夫曼编码不完整，所以将换行符输出为"\n"（斜杠加字母n）
            }
            else first = s[++i];
            this->char_count[first] = second;
            second=0;
            continue;
        }
        second *= 10;
        second+=s[i]-'0';
    }
    this->hf = new HuffmanTree(this->char_count);
    char in;
    ll byte_count=0;
    infile.read(&in,1);
    int code;
    Node* temp = this->hf->root;
    while(byte_count<file->length){
        for(int i=0;i<8;i++){
            if(temp->value!=-129){              //-129是设定用来区分结点是否代表某个char的值，-129说明结点不代表某个char
            this->outfile<<char(temp->value);
            temp = this->hf->root;
            byte_count++;
            if(byte_count == file->length)break;
            }
            code = in & 128;            //获取in最高位的数字
            if(code){                //左'0'右‘1’
                temp = temp->right;
            }
            else temp = temp->left;
            in = in<<1;                 //in左移一位
        }
        if(temp->value!=-129){                  //处理末位的情况
            this->outfile<<char(temp->value);
            temp = this->hf->root;
            byte_count++;

        }
        infile.read(&in,1);
        
    }
    this->outfile.close();
}
void char_to_string(char in,char buff[8]){
    int divide = 128;
    unsigned char char_in = (unsigned char)in;
    int int_in = (int)char_in;
    for(int i=0;i<8;i++){
        buff[i] = int_in/divide+'0';
        int_in = int_in%divide;
        divide/=2;
    }
}
void Decompress::visit(Element* const element){
    if(element->type=="Folder")return;
    this->infile.open(element->path,ios::binary);
    if(!infile)cout<<"Decom Infile error"<<endl;
    this->decompress();
}
string get_name(string line,int idx){
    string ans="";
    for(int i=idx;i<line.size();i++){
        if(line[i]=='\n' || line[i]==' ')break;
        ans+=line[i];
    }
    return ans;
}

void Decompress::decompress(){
    string line;
    line = sub_str(line,0);
    string dir = "./";
    int level = 0;
    while(!infile.eof()){
        getline(infile,line);
        int idx = Cal_space(line);
        if(level>idx){
            int temp = level;
            for(int i=0;i<temp-idx;i++){
                dir = Parent_dir(dir);
                level--;
            }
        }
        if(isFile(line)){                   //文件
            int idx1 = idx;
            int idx2 = line.rfind(' ');
            int idx3 = line.rfind(':');
            string name = line.substr(idx1,idx2-idx1); 
            string path = dir;
            path+=name;
            string s_origin_len = sub_str(line,idx2+1);
            string tem_com_len = sub_str(line,idx3+1);
            string s_com_len = Delete_comma(tem_com_len);
            ll length = atoi(s_origin_len.c_str());
            ll com_len = atoi(s_com_len.c_str());
            File* file = new File(path,name);
            file->length = length;
            file->com_length = com_len;

            ifstream inf(file->path,ios::binary);
            if(inf){
                cout<<"File "<<file->path<<" existed,do you want to overwrite it(Y/N)"<<endl;
                string s;
                while(1){
                    cin>>s;
                    if(s=="Y"||s=="N")break;
                    else cout<<"Format error.Try again"<<endl;
                }
                inf.close();
                if(s=="N"){
                    return;
                }
            }
            this->decom_file(file);
            
        }
        else{                               //文件夹
            string name = sub_str(line,idx);
            dir+=name;
            dir+="/";
            level++;
            fs::create_directories(dir);
        }
    }   
}

