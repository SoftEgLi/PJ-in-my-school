//实现霍夫曼树和霍夫曼编码的搭建函数。

#include"HuffmanTree.h"
#include<algorithm>
void HuffmanTree::recursion(map<char,string>& binary_map,Node* node,string prefix){
    if(node ==NULL)return;
    if(node->value!=-129){
        // cout<<"Node:"<<node->value<<"="<<prefix<<endl;
        binary_map[node->value] = prefix;
    }
    recursion(binary_map,node->left,prefix+"0");
    recursion(binary_map,node->right,prefix+"1");
}
map<char,string> HuffmanTree::Create_Code(){
    map<char,string> ans;
    recursion(ans,root,"");
    return ans;
}
bool cmp(Node* n1,Node* n2){
    return n1->getweight() > n2->getweight();
}
HuffmanTree::HuffmanTree(map<char,ll> map_count){           //用最小堆来建立Huffman树
    int n = map_count.size();
    vector<Node*> heap(n);
    auto end = map_count.end();
    int i= 0;
    for(auto iter = map_count.begin();iter!=end;iter++){    //初始化
        heap[i] = new Node(iter->first,iter->second,NULL,NULL);
        i++;
    }
    make_heap(heap.begin(),heap.end(),cmp);                 //建立最小堆，cmp是比较函数
    Node* first,*second,*parent;
    for(i = 0;i < n-1;i++){                 //做n-1次，形成Huffman树
        pop_heap(heap.begin(),heap.end(),cmp);
        first = heap.back();                    //最小的元素
        heap.pop_back();
        pop_heap(heap.begin(),heap.end(),cmp);
        second = heap.back();
        heap.pop_back();                   //次小的元素
        parent = new Node(-129,first->weight + second->weight,first,second);
        heap.push_back(parent);
        push_heap(heap.begin(),heap.end(),cmp);
        this->root = parent;
    }
}
